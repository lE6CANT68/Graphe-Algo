var searchData=
[
  ['ibm8514_0',['IBM8514',['../graphics_8h.html#aad79b2d9876d773e33c9f2e38be040d2',1,'graphics.h']]],
  ['ibm8514hi_1',['IBM8514HI',['../graphics_8h.html#a53fe6fd6846efc54c589b49a03d850ad',1,'graphics.h']]],
  ['ibm8514lo_2',['IBM8514LO',['../graphics_8h.html#af67f75b25a85e92edd15ee1566f2fe73',1,'graphics.h']]]
];
