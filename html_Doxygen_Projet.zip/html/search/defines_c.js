var searchData=
[
  ['palette_5fsize_0',['PALETTE_SIZE',['../winbgi_8cpp.html#a0d5a8d0e21c3925cbf2ea6f4d5fb5643',1,'winbgi.cpp']]],
  ['pc3270_1',['PC3270',['../graphics_8h.html#a2884b49df7a0ddc20709a62c4331c0d5',1,'graphics.h']]],
  ['pc3270hi_2',['PC3270HI',['../graphics_8h.html#aa79281860d0d6808cd9480661672aa4d',1,'graphics.h']]],
  ['pen_5fcache_5fsize_3',['PEN_CACHE_SIZE',['../winbgi_8cpp.html#abeb844a03f0ce961f0432ec23f2ef6d4',1,'winbgi.cpp']]]
];
