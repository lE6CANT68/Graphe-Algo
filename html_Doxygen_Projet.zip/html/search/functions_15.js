var searchData=
[
  ['waituntilbuttonpressed_0',['waituntilbuttonpressed',['../graphics_8h.html#a6761c0d77720aa4f89c32992e74ae72e',1,'waituntilbuttonpressed():&#160;winbgi.cpp'],['../winbgi_8cpp.html#a6761c0d77720aa4f89c32992e74ae72e',1,'waituntilbuttonpressed():&#160;winbgi.cpp']]],
  ['waituntilkeypressed_1',['waituntilkeypressed',['../graphics_8h.html#aa5cfb203c3d54e914fbc4fa911433ccb',1,'waituntilkeypressed():&#160;winbgi.cpp'],['../winbgi_8cpp.html#aa5cfb203c3d54e914fbc4fa911433ccb',1,'waituntilkeypressed():&#160;winbgi.cpp']]],
  ['wndproc_2',['WndProc',['../winbgi_8cpp.html#a8bd1700066f57687fb806bf87b433da1',1,'winbgi.cpp']]]
];
