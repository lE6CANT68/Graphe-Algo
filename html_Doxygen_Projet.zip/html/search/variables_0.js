var searchData=
[
  ['ac_0',['ac',['../winbgi_8cpp.html#abf55b11fb222f654a5598b201c48d5e1',1,'winbgi.cpp']]],
  ['active_5fpage_1',['active_page',['../winbgi_8cpp.html#a411350e1b494c148db67938482c84a7b',1,'winbgi.cpp']]],
  ['aspect_5fratio_5fx_2',['aspect_ratio_x',['../winbgi_8cpp.html#a1a6472bc3d8277f9e41cf83a2649e222',1,'winbgi.cpp']]],
  ['aspect_5fratio_5fy_3',['aspect_ratio_y',['../winbgi_8cpp.html#a23267e324060cb3f845a3668578014b1',1,'winbgi.cpp']]]
];
