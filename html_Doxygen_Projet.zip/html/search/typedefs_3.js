var searchData=
[
  ['palettetype_0',['palettetype',['../graphics_8h.html#a5fa1215205d53920645bc99ecdf9737c',1,'graphics.h']]]
];
