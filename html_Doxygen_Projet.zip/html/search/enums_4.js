var searchData=
[
  ['text_5fdirections_0',['text_directions',['../graphics_8h.html#abe43627f27b5357e6e7f49824edfa6f4',1,'graphics.h']]]
];
