var searchData=
[
  ['next_0',['next',['../classl2elem.html#aff1d38b8fc49b41e450c4d898e1eb3e3',1,'l2elem']]],
  ['normal_5ffont_5fsize_1',['normal_font_size',['../winbgi_8cpp.html#a79b7734cf6e1b3c6469c7651c0fb7c4e',1,'winbgi.cpp']]]
];
