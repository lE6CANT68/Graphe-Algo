var searchData=
[
  ['hatchbrushbitmap_0',['HatchBrushBitmap',['../winbgi_8cpp.html#a62b2c39dea9392f07039957310df4dc1',1,'winbgi.cpp']]],
  ['hauteurfenetregraphe_1',['hauteurFenetreGraphe',['../class_interface.html#a24ff814a4f93f468e4fbaf25f31fb2a3',1,'Interface']]],
  ['hbackgroundbrush_2',['hBackgroundBrush',['../winbgi_8cpp.html#a40436d1ada05329f95538e97658e012b',1,'winbgi.cpp']]],
  ['hbitmap_3',['hBitmap',['../winbgi_8cpp.html#a1a7519214a2514722826205d15a8e167',1,'winbgi.cpp']]],
  ['hbrush_4',['hBrush',['../winbgi_8cpp.html#aaafdfd8a67a15709443d39637e91f1cb',1,'winbgi.cpp']]],
  ['hdc_5',['hdc',['../winbgi_8cpp.html#a73df15e851e642a5d2afa251688ef0d3',1,'winbgi.cpp']]],
  ['hdr_6',['hdr',['../struct_b_g_ibitmapinfo.html#a7ab87dc6b340295d5031ca8bec44774b',1,'BGIbitmapinfo']]],
  ['height_7',['height',['../struct_b_g_iimage.html#aa2e2e1553f1b6ba6dcf8ff0c3019ff76',1,'BGIimage::height'],['../classfont__cache_1_1font__cache__item.html#a307f4bb6b4f81fd7216bfd28bfab5f52',1,'font_cache::font_cache_item::height'],['../winbgi_8cpp.html#ad12fc34ce789bce6c8a05d8a17138534',1,'height:&#160;winbgi.cpp']]],
  ['hfont_8',['hFont',['../winbgi_8cpp.html#a0b01dd58c861d0bc8dcdf6ecf1502dfd',1,'winbgi.cpp']]],
  ['horiz_9',['horiz',['../structtextsettingstype.html#a28143d2c28ee47b783816020e13d3da5',1,'textsettingstype']]],
  ['hpalette_10',['hPalette',['../winbgi_8cpp.html#a34c54f1a237420fb59f07d0a820ee63a',1,'winbgi.cpp']]],
  ['hpen_11',['hPen',['../winbgi_8cpp.html#a7b9435c39af65b3df813b37215df7f17',1,'winbgi.cpp']]],
  ['hputimagebitmap_12',['hPutimageBitmap',['../winbgi_8cpp.html#a7280546c90940dd282df10fb5b8c89d3',1,'winbgi.cpp']]],
  ['hrgn_13',['hRgn',['../winbgi_8cpp.html#a35950964732771fa33a8594dd51fd219',1,'winbgi.cpp']]],
  ['hwnd_14',['hWnd',['../winbgi_8cpp.html#afec4341c234519e145bac6f0e5edaa51',1,'winbgi.cpp']]]
];
