var searchData=
[
  ['fermerfenetre_0',['fermerFenetre',['../class_interface.html#af91382baf6a69fb904aebf4c725b4f8a',1,'Interface']]],
  ['fillellipse_1',['fillellipse',['../graphics_8h.html#ae6f672e602f7862ea4b3190a939001ec',1,'fillellipse(int x, int y, int rx, int ry):&#160;winbgi.cpp'],['../winbgi_8cpp.html#ae6f672e602f7862ea4b3190a939001ec',1,'fillellipse(int x, int y, int rx, int ry):&#160;winbgi.cpp']]],
  ['fillpoly_2',['fillpoly',['../graphics_8h.html#a5837c7c489cda35b1934394c56d592a7',1,'fillpoly(int, int *):&#160;winbgi.cpp'],['../winbgi_8cpp.html#aed77000563a91b16c05041e1c257543f',1,'fillpoly(int n_points, int *points):&#160;winbgi.cpp']]],
  ['floodfill_3',['floodfill',['../graphics_8h.html#a531e61544eecc159a508096196a4463c',1,'floodfill(int x, int y, int border):&#160;winbgi.cpp'],['../winbgi_8cpp.html#a531e61544eecc159a508096196a4463c',1,'floodfill(int x, int y, int border):&#160;winbgi.cpp']]],
  ['font_5fcache_4',['font_cache',['../classfont__cache.html#a064b5d9b36c617d3050a09e829af4c71',1,'font_cache']]]
];
