var searchData=
[
  ['cache_0',['cache',['../classpen__cache.html#abd13973ea11bae0b70c0452a96213783',1,'pen_cache::cache'],['../classfont__cache.html#a1250440d0090aa5680bdc21e7f3e0e45',1,'font_cache::cache']]],
  ['charsize_1',['charsize',['../structtextsettingstype.html#a9742c241f7b8e5c63ab28bb2513dfde4',1,'textsettingstype']]],
  ['clip_2',['clip',['../structviewporttype.html#afbcd3b2424162f317f299adde62ea7e6',1,'viewporttype']]],
  ['closedotbrushbitmap_3',['ClosedotBrushBitmap',['../winbgi_8cpp.html#a33c087d5c0ee0a1f1eb036209ab467dc',1,'winbgi.cpp']]],
  ['color_4',['color',['../structfillsettingstype.html#a14b16ad1a6aa454d3b59802d402776a1',1,'fillsettingstype::color'],['../classpen__cache_1_1pen__cache__item.html#ab18bf4e08b419a7086662d1b9a60f65a',1,'pen_cache::pen_cache_item::color'],['../winbgi_8cpp.html#a0fd02fb9277ffcb35a75066ffe95e8c7',1,'color:&#160;winbgi.cpp']]],
  ['color_5ftable_5',['color_table',['../struct_b_g_ibitmapinfo.html#a0a61e0a648ad96986a717492f883fd01',1,'BGIbitmapinfo']]],
  ['colors_6',['colors',['../structpalettetype.html#a283ac9aae8cf5bce0d438f44399e2684',1,'palettetype']]],
  ['current_5fpalette_7',['current_palette',['../winbgi_8cpp.html#a1fe45277b8d12f076ed839c1b6c36696',1,'winbgi.cpp']]]
];
