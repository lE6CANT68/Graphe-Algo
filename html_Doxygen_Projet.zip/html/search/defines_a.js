var searchData=
[
  ['max_5fpages_0',['MAX_PAGES',['../winbgi_8cpp.html#a85f89e842475a0305bb474a98d61bdfe',1,'winbgi.cpp']]],
  ['maxcolors_1',['MAXCOLORS',['../graphics_8h.html#a653a781f54d9d640c5dc8eb5360892a9',1,'graphics.h']]],
  ['mcga_2',['MCGA',['../graphics_8h.html#a875afe0451df8a6d45c4c55a5b758bb2',1,'graphics.h']]],
  ['mcgac0_3',['MCGAC0',['../graphics_8h.html#a16187c510853e85c2dbd3a44c2765014',1,'graphics.h']]],
  ['mcgac1_4',['MCGAC1',['../graphics_8h.html#aa7861cd104cb557f1d67a4ee5125174f',1,'graphics.h']]],
  ['mcgac2_5',['MCGAC2',['../graphics_8h.html#a46261be7a86559d70379a03e9c174bdf',1,'graphics.h']]],
  ['mcgac3_6',['MCGAC3',['../graphics_8h.html#af1db59c7cb52d300f270ad417238a247',1,'graphics.h']]],
  ['mcgahi_7',['MCGAHI',['../graphics_8h.html#a2505ee640a48fa94ddc519774c34c8bf',1,'graphics.h']]],
  ['mcgamed_8',['MCGAMED',['../graphics_8h.html#afeab2a52f3d76d4545e26f70228bf537',1,'graphics.h']]]
];
