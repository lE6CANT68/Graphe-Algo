var searchData=
[
  ['text_5falign_5fmode_0',['text_align_mode',['../winbgi_8cpp.html#a9cd9a4a4752524d5c24a9bf5ef595e0d',1,'winbgi.cpp']]],
  ['text_5fcolor_1',['text_color',['../winbgi_8cpp.html#a0d18f7f6a98a31dadb62c4227bb653d3',1,'winbgi.cpp']]],
  ['text_5fhalign_5fcnv_2',['text_halign_cnv',['../winbgi_8cpp.html#affe35843a4e8b609f84d10b9ae0bc016',1,'winbgi.cpp']]],
  ['text_5fsettings_3',['text_settings',['../winbgi_8cpp.html#a66aeddbf2531b2112f509787a914f4c3',1,'winbgi.cpp']]],
  ['text_5fvalign_5fcnv_4',['text_valign_cnv',['../winbgi_8cpp.html#a6390989c1251efe27c9612e82062b33a',1,'winbgi.cpp']]],
  ['thickness_5',['thickness',['../structlinesettingstype.html#a6f33efd53905e655bccff0d30c1b0639',1,'linesettingstype']]],
  ['timeout_5fexpired_6',['timeout_expired',['../winbgi_8cpp.html#a1abb6084f3ad1271b5184b4d938d9e0a',1,'winbgi.cpp']]],
  ['top_7',['top',['../structviewporttype.html#a6f02ec82ba9b569e6e2b960a698b49b2',1,'viewporttype']]],
  ['type_8',['type',['../classfont__cache_1_1font__cache__item.html#af25095430e90e16ead5a5d94f01cafcf',1,'font_cache::font_cache_item']]]
];
