var searchData=
[
  ['_5f_5fcolors_0',['__COLORS',['../graphics_8h.html#ad630bb63d849eed00c9b908408b5a696',1,'graphics.h']]]
];
