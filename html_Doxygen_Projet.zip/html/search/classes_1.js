var searchData=
[
  ['bgibitmapinfo_0',['BGIbitmapinfo',['../struct_b_g_ibitmapinfo.html',1,'']]],
  ['bgiimage_1',['BGIimage',['../struct_b_g_iimage.html',1,'']]]
];
