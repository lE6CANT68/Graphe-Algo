var searchData=
[
  ['bg_0',['BG',['../winbgi_8cpp.html#ab05cfd0a3a5e9ed76d38482e2cd26f9f',1,'winbgi.cpp']]],
  ['border_5fheight_1',['BORDER_HEIGHT',['../winbgi_8cpp.html#a8d1345c22c668be330e8ff3ee4fb2463',1,'winbgi.cpp']]],
  ['border_5fwidth_2',['BORDER_WIDTH',['../winbgi_8cpp.html#a4221b0a24a1716cf086b820f988e4285',1,'winbgi.cpp']]],
  ['bottom_5ftext_3',['BOTTOM_TEXT',['../graphics_8h.html#a02b7607c323731f6b5d4c4aba6eb8f70',1,'graphics.h']]]
];
