var searchData=
[
  ['fcache_0',['fcache',['../winbgi_8cpp.html#a3c94d462bdc75abf698e9a4db6e171ed',1,'winbgi.cpp']]],
  ['fenetreouverte_1',['fenetreOuverte',['../class_interface.html#a1357d14303f578a3fd62a8d9f45d9a05',1,'Interface']]],
  ['fill_5fsettings_2',['fill_settings',['../winbgi_8cpp.html#a585cba4555ee65a4b5c899c183327cb6',1,'winbgi.cpp']]],
  ['font_3',['font',['../structtextsettingstype.html#ad02fcb9f42bc0d2d3f4583ce47edd733',1,'textsettingstype::font'],['../classfont__cache_1_1font__cache__item.html#a0a0a2c67f51b28413b38dfc792dd4aaf',1,'font_cache::font_cache_item::font']]],
  ['font_5fdiv_5fx_4',['font_div_x',['../winbgi_8cpp.html#af32706a18b61f717a172a34ee0101582',1,'winbgi.cpp']]],
  ['font_5fdiv_5fy_5',['font_div_y',['../winbgi_8cpp.html#aa484991281b141d08480836a82403f54',1,'winbgi.cpp']]],
  ['font_5ffamily_6',['font_family',['../winbgi_8cpp.html#a49a508a6694433aa371d971a38b3cdf6',1,'winbgi.cpp']]],
  ['font_5fmetrics_7',['font_metrics',['../winbgi_8cpp.html#acf04ce9171f40ba56314785df7b49d6c',1,'winbgi.cpp']]],
  ['font_5fmul_5fx_8',['font_mul_x',['../winbgi_8cpp.html#a23c994fe3539add6dcf10f18d9721305',1,'winbgi.cpp']]],
  ['font_5fmul_5fy_9',['font_mul_y',['../winbgi_8cpp.html#aad74d6dd2baf0e787482e8a484481993',1,'winbgi.cpp']]],
  ['font_5fname_10',['font_name',['../winbgi_8cpp.html#adf595bb5b5bf65fba48215bb7c87b0d0',1,'winbgi.cpp']]],
  ['font_5fweight_11',['font_weight',['../winbgi_8cpp.html#a0bee4108d7e64af81f0d63a68f9b598d',1,'winbgi.cpp']]],
  ['free_12',['free',['../classpen__cache.html#ab8b3548c746c19f621ab6dd7f1128c2e',1,'pen_cache::free'],['../classfont__cache.html#ae1b8420eb2b09c160bffbbb5ade17957',1,'font_cache::free']]]
];
