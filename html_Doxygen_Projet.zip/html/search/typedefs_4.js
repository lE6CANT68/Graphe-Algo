var searchData=
[
  ['textsettingstype_0',['textsettingstype',['../graphics_8h.html#a99cb100ace2211de4bc392f7ab7c8ff2',1,'graphics.h']]]
];
