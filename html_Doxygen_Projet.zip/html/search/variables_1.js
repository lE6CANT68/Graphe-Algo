var searchData=
[
  ['bgicolor_0',['BGIcolor',['../winbgi_8cpp.html#af8d0e63e518547c51737c5d530cfec7f',1,'winbgi.cpp']]],
  ['bgiemu_5fdefault_5fmode_1',['bgiemu_default_mode',['../graphics_8h.html#a8caf6707f4bb4877af87e4731d9f0771',1,'bgiemu_default_mode:&#160;winbgi.cpp'],['../winbgi_8cpp.html#a8caf6707f4bb4877af87e4731d9f0771',1,'bgiemu_default_mode:&#160;winbgi.cpp']]],
  ['bgiemu_5fhandle_5fredraw_2',['bgiemu_handle_redraw',['../graphics_8h.html#aacf82343d81f56774d5911aa00e26e3a',1,'bgiemu_handle_redraw:&#160;winbgi.cpp'],['../winbgi_8cpp.html#aacf82343d81f56774d5911aa00e26e3a',1,'bgiemu_handle_redraw:&#160;winbgi.cpp']]],
  ['bgipalette_3',['BGIpalette',['../winbgi_8cpp.html#a3f2b7c56590e82003c43ec0f8bebfc65',1,'winbgi.cpp']]],
  ['bitblt_5fmode_5fcnv_4',['bitblt_mode_cnv',['../winbgi_8cpp.html#a77136f54c79ef780a11d32ff169eaa0a',1,'winbgi.cpp']]],
  ['bits_5',['bits',['../struct_b_g_iimage.html#a29ed0f0d276404975be4ae5e31c843fc',1,'BGIimage']]],
  ['bkcolor_6',['bkcolor',['../winbgi_8cpp.html#ac8f5cfabfc07d4168ac9e04569ca6625',1,'winbgi.cpp']]],
  ['bkslashbrushbitmap_7',['BkslashBrushBitmap',['../winbgi_8cpp.html#ace78040dae94120181035bb858274208',1,'winbgi.cpp']]],
  ['bminfo_8',['bminfo',['../winbgi_8cpp.html#a8a5f49417a2d1eec3c42e1f3bc6e5649',1,'winbgi.cpp']]],
  ['bottom_9',['bottom',['../structviewporttype.html#a73ac91b9d4fcd130e898e38864de5fde',1,'viewporttype']]]
];
