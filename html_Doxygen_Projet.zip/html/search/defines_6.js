var searchData=
[
  ['far_0',['far',['../graphics_8h.html#a0996c29b5fdd7baa181e30274b2378b7',1,'graphics.h']]],
  ['flags_1',['FLAGS',['../winbgi_8cpp.html#a6ccad09b4a2a06ae178418fdccf5940d',1,'winbgi.cpp']]],
  ['font_5fcache_5fsize_2',['FONT_CACHE_SIZE',['../winbgi_8cpp.html#ad39c8b2d14ac3c82b2c29d5f19457fc2',1,'winbgi.cpp']]]
];
