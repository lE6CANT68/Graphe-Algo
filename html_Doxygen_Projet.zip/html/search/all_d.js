var searchData=
[
  ['next_0',['next',['../classl2elem.html#aff1d38b8fc49b41e450c4d898e1eb3e3',1,'l2elem']]],
  ['norm_5fwidth_1',['NORM_WIDTH',['../graphics_8h.html#a04bbd93385584232810944e355bd20fb',1,'graphics.h']]],
  ['normal_5ffont_5fsize_2',['normal_font_size',['../winbgi_8cpp.html#a79b7734cf6e1b3c6469c7651c0fb7c4e',1,'winbgi.cpp']]],
  ['not_5fput_3',['NOT_PUT',['../graphics_8h.html#afa50b3bb9bd621c1215a0e9b3221e507a9fc6e07e01468547fa26c4780f95481a',1,'graphics.h']]],
  ['not_5fupdate_5fcp_4',['NOT_UPDATE_CP',['../winbgi_8cpp.html#adf764cbdea00d65edcd07bb9953ad2b7a3daa86576d47c2a848736876a9209d75',1,'winbgi.cpp']]]
];
