var searchData=
[
  ['_5fgraphfreemem_0',['_graphfreemem',['../graphics_8h.html#a3543be412e3723ae7a59cb62742aa6d6',1,'graphics.h']]],
  ['_5fgraphgetmem_1',['_graphgetmem',['../graphics_8h.html#a3cb1f00ac98672a13894b77c0e12a862',1,'graphics.h']]]
];
