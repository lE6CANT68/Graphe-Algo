var searchData=
[
  ['screen_5fheight_0',['screen_height',['../winbgi_8cpp.html#a3b4a1bd850991355b91c7bfc15247d49',1,'winbgi.cpp']]],
  ['screen_5fwidth_1',['screen_width',['../winbgi_8cpp.html#aa4d434a8b93410ea0ed660e48dac41c6',1,'winbgi.cpp']]],
  ['size_2',['size',['../structpalettetype.html#a1984bf789dd2410b32329439b86bb619',1,'palettetype']]],
  ['slashbrushbitmap_3',['SlashBrushBitmap',['../winbgi_8cpp.html#a8e53e55bc3a258c2d26c6cdccb351e31',1,'winbgi.cpp']]],
  ['solidbrushbitmap_4',['SolidBrushBitmap',['../winbgi_8cpp.html#abd22a9b24a980ac737696f0c0128e947',1,'winbgi.cpp']]],
  ['style_5',['style',['../classpen__cache_1_1pen__cache__item.html#a9b6bb9504164e6960b5475c5636a9ef6',1,'pen_cache::pen_cache_item']]]
];
