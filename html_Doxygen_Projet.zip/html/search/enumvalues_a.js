var searchData=
[
  ['not_5fput_0',['NOT_PUT',['../graphics_8h.html#afa50b3bb9bd621c1215a0e9b3221e507a9fc6e07e01468547fa26c4780f95481a',1,'graphics.h']]],
  ['not_5fupdate_5fcp_1',['NOT_UPDATE_CP',['../winbgi_8cpp.html#adf764cbdea00d65edcd07bb9953ad2b7a3daa86576d47c2a848736876a9209d75',1,'winbgi.cpp']]]
];
