var searchData=
[
  ['gdi_5ferror_5fcode_0',['gdi_error_code',['../winbgi_8cpp.html#ad55f66b53c44ff56486aee541767e593',1,'winbgi.cpp']]],
  ['graphdriver_1',['GraphDriver',['../winbgi_8cpp.html#ae183ac94fa34d69701c2424ec5066678',1,'winbgi.cpp']]],
  ['graphmode_2',['GraphMode',['../winbgi_8cpp.html#a45ad899b29e31efa29f6dd01002fd035',1,'winbgi.cpp']]]
];
