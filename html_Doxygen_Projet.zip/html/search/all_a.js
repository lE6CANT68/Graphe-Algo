var searchData=
[
  ['kbd_5fqueue_0',['kbd_queue',['../winbgi_8cpp.html#ac02e997a4157dc14098d695b8e941041',1,'winbgi.cpp']]],
  ['kbhit_1',['kbhit',['../graphics_8h.html#a97e9b1fe8d4c010474637a654aad6566',1,'kbhit(void):&#160;winbgi.cpp'],['../winbgi_8cpp.html#ad5451da499ab9d3907da8dd7060ab677',1,'kbhit():&#160;winbgi.cpp']]],
  ['keypressed_2',['keypressed',['../graphics_8h.html#ab01c68c22c20faed6e83d44684ba3a0a',1,'keypressed(void):&#160;winbgi.cpp'],['../winbgi_8cpp.html#a23c933dcfb4185c5d0a4d89e1f89fe34',1,'keypressed():&#160;winbgi.cpp']]]
];
