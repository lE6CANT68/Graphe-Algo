var searchData=
[
  ['textsettingstype_0',['textsettingstype',['../structtextsettingstype.html',1,'']]]
];
