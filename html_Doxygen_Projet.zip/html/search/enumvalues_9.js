var searchData=
[
  ['magenta_0',['MAGENTA',['../graphics_8h.html#aedd64c3f92da850b93776c65fd1cced3a56926c820ad72d0977e7ee44d9916e62',1,'graphics.h']]]
];
