var structviewporttype =
[
    [ "bottom", "structviewporttype.html#a73ac91b9d4fcd130e898e38864de5fde", null ],
    [ "clip", "structviewporttype.html#afbcd3b2424162f317f299adde62ea7e6", null ],
    [ "left", "structviewporttype.html#ae53f6e7ed03edd2ac8e309cd83679ead", null ],
    [ "right", "structviewporttype.html#a4c46eb242e1d1e80e329346fa609abe2", null ],
    [ "top", "structviewporttype.html#a6f02ec82ba9b569e6e2b960a698b49b2", null ]
];