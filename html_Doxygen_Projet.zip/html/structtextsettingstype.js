var structtextsettingstype =
[
    [ "charsize", "structtextsettingstype.html#a9742c241f7b8e5c63ab28bb2513dfde4", null ],
    [ "direction", "structtextsettingstype.html#a1b2cf1064de1a25f4c6503ec62d3c427", null ],
    [ "font", "structtextsettingstype.html#ad02fcb9f42bc0d2d3f4583ce47edd733", null ],
    [ "horiz", "structtextsettingstype.html#a28143d2c28ee47b783816020e13d3da5", null ],
    [ "vert", "structtextsettingstype.html#a9048caff59e54290c70e4482f87f60b4", null ]
];