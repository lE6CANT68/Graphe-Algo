var structlinesettingstype =
[
    [ "linestyle", "structlinesettingstype.html#a244e7855ca26c1667bc3f3e9620340c5", null ],
    [ "thickness", "structlinesettingstype.html#a6f33efd53905e655bccff0d30c1b0639", null ],
    [ "upattern", "structlinesettingstype.html#a73571512adef1389de3d0d123a162322", null ]
];