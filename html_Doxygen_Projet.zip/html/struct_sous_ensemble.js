var struct_sous_ensemble =
[
    [ "parent", "struct_sous_ensemble.html#a666ab73228eaa06a416643445fe1173b", null ],
    [ "rang", "struct_sous_ensemble.html#a4e6fe54ba92613761afe77d3da3bb784", null ]
];