var _interface_8cpp =
[
    [ "d_hwnd", "_interface_8cpp.html#a1445deadffd840babf8f2112063ba363", null ]
];