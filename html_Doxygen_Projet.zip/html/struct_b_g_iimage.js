var struct_b_g_iimage =
[
    [ "bits", "struct_b_g_iimage.html#a29ed0f0d276404975be4ae5e31c843fc", null ],
    [ "height", "struct_b_g_iimage.html#aa2e2e1553f1b6ba6dcf8ff0c3019ff76", null ],
    [ "reserved", "struct_b_g_iimage.html#a8dbf97c7c8c77831b37faac0c7b4b4fe", null ],
    [ "width", "struct_b_g_iimage.html#a71bbb7970eca28769174235ae132d1c4", null ]
];