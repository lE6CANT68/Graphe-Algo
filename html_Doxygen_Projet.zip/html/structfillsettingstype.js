var structfillsettingstype =
[
    [ "color", "structfillsettingstype.html#a14b16ad1a6aa454d3b59802d402776a1", null ],
    [ "pattern", "structfillsettingstype.html#a3a86b8c6a06f8648be847f17b90c0d5c", null ]
];