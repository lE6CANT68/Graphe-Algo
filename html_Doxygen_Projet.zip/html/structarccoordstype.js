var structarccoordstype =
[
    [ "x", "structarccoordstype.html#a37dedbbdfb1a42fa08da9b9353a4d7d7", null ],
    [ "xend", "structarccoordstype.html#aadb2d6cd8010d7dde0e12994b9406d0c", null ],
    [ "xstart", "structarccoordstype.html#a21d2d58404a892b27315137b3faec709", null ],
    [ "y", "structarccoordstype.html#a8cb75a253532ba0883b5afb9dba7a79b", null ],
    [ "yend", "structarccoordstype.html#a063e74e73c3389dc40e60e498a38ce09", null ],
    [ "ystart", "structarccoordstype.html#a8dc3851c51363a495865a370a75e1dc3", null ]
];