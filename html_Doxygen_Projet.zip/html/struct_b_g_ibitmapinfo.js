var struct_b_g_ibitmapinfo =
[
    [ "color_table", "struct_b_g_ibitmapinfo.html#a0a61e0a648ad96986a717492f883fd01", null ],
    [ "hdr", "struct_b_g_ibitmapinfo.html#a7ab87dc6b340295d5031ca8bec44774b", null ]
];