var structpalettetype =
[
    [ "colors", "structpalettetype.html#a283ac9aae8cf5bce0d438f44399e2684", null ],
    [ "size", "structpalettetype.html#a1984bf789dd2410b32329439b86bb619", null ]
];