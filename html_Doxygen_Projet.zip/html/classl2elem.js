var classl2elem =
[
    [ "link_after", "classl2elem.html#aef0c7aed9bfe218678b4a9fc8eff3b0f", null ],
    [ "prune", "classl2elem.html#adc2475191b8d81479ac8f0737cdf879b", null ],
    [ "unlink", "classl2elem.html#a046e5173f5916788a62e43784adb662d", null ],
    [ "next", "classl2elem.html#aff1d38b8fc49b41e450c4d898e1eb3e3", null ],
    [ "prev", "classl2elem.html#a091a06456cd2eb71c16ddf00abfe8499", null ]
];